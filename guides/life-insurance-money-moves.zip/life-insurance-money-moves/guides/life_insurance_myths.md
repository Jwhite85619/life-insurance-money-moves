# Common Myths About Life Insurance

- Myth: "Life insurance is only for the elderly." — False.
- Myth: "Term is always cheaper for everyone." — Term is cheaper short-term; permanent adds value over time.
- Myth: "You can't borrow from a policy." — You can via policy loans/withdrawals.

Ask us for examples tailored to your situation.
