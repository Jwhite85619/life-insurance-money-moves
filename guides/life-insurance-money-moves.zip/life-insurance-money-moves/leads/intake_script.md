# Intake Script (call)
1. Intro & confirm name.
2. Ask about current coverage and goals.
3. Offer the free guide and schedule a 15-min consult.
