# Needs Analysis Worksheet (instructions)
1. List household monthly expenses.
2. Multiply by 12 and add debts and future goals (education, mortgage payoff).
3. Subtract liquid assets and expected social benefits.
4. The result approximates needed death benefit to replace income/goals.
