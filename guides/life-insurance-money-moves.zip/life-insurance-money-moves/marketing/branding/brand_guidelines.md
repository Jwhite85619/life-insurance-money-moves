Brand: Life Insurance Money Moves
Tone: Professional, empowering, money-focused
Fonts: Use clean sans-serif (e.g., Montserrat, Inter)
Imagery: Navy blue backgrounds, white text, shield/dollar motifs
